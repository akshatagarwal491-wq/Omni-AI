import "dotenv/config";
import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const port = Number(process.env.PORT || 8787);
const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(client), app: "OMNI" });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) return res.status(503).json({ error: "OMNI needs an OpenAI API key. Add it to your server .env file." });
    const { messages, model } = req.body ?? {};
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 40) {
      return res.status(400).json({ error: "Send between 1 and 40 messages." });
    }
    const safeMessages = messages.map((m) => {
      if (!["user", "assistant"].includes(m.role) || typeof m.content !== "string") {
        throw new Error("Invalid message format.");
      }
      return { role: m.role, content: m.content.slice(0, 12000) };
    });
    const response = await client.responses.create({
      model: typeof model === "string" && /^gpt-[a-zA-Z0-9.-]+$/.test(model) ? model : (process.env.OPENAI_MODEL || "gpt-4.1-mini"),
      instructions: "You are OMNI, a helpful, thoughtful, capable AI assistant. Be clear, accurate, and friendly. Admit uncertainty and never invent facts.",
      input: safeMessages
    });
    res.json({ reply: response.output_text || "I couldn't produce a text response. Please try again." });
  } catch (error) {
    console.error("OMNI chat error:", error?.message || error);
    res.status(500).json({ error: error?.message || "Something went wrong. Please try again." });
  }
});

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const distPath = path.resolve(__dirname, "../dist");
app.use(express.static(distPath));
app.get("/{*splat}", (_req, res) => res.sendFile(path.join(distPath, "index.html")));

app.listen(port, () => console.log(`OMNI server running on http://localhost:${port}`));