# OMNI — AI assistant starter

A responsive web app that can also be packaged as an Android app with Capacitor. It uses the OpenAI Responses API from a server-side endpoint so your API key is not exposed in the browser.

## What works in this starter
- Responsive ChatGPT-inspired interface for desktop and mobile
- Multiple chats, local chat history, new chat, delete chat
- OpenAI-powered text conversations through the Responses API
- Model selector (availability depends on your API account)
- Dark/light theme
- Installable PWA manifest

## Requirements
- Node.js 20.19+ or 22.12+
- An OpenAI API key and API billing/credits
- Android Studio only if you want to build/install the Android app

## Run locally
1. Extract the project.
2. In the project folder run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your API key in `.env` as `OPENAI_API_KEY=...`. Do not put it in frontend code.
5. In one terminal run `npm run server`.
6. In another terminal run `npm run dev`.
7. Open the Vite URL shown in the terminal (normally http://localhost:5173).

The API server runs on port 8787. For local development, configure a proxy in `vite.config.js` if needed. Add this `server.proxy` setting to the Vite config:
`proxy: { "/api": "http://localhost:8787" }`
(See the note below.)

## Important local development note
Edit `vite.config.js` to:
`export default defineConfig({ plugins: [react()], server: { port: 5173, proxy: { "/api": "http://localhost:8787" } } });`

## Production
Build the frontend with `npm run build`, then run `npm run server`. Deploy the combined Node server to a Node-compatible host and set `OPENAI_API_KEY`, `OPENAI_MODEL`, and `PORT` as environment variables. Use HTTPS, authentication, rate limiting, and usage limits before public launch. The starter stores chat history in the user's browser only.

## Android
1. Build and deploy the web app to an HTTPS URL, or use a development server.
2. Run `npm run build`.
3. Run `npx cap add android` once.
4. Run `npx cap sync android`.
5. Run `npx cap open android` and build the APK/AAB in Android Studio.

For a production Android app, point Capacitor to your hosted app or configure an appropriate server URL. Do not embed your OpenAI API key in the Android app. The key must remain on your backend.

## Not included yet
Image/file uploads, voice conversations, account sign-in, cloud-synced history, streaming responses, billing, moderation/rate limiting, and production security hardening. These are good next milestones.
