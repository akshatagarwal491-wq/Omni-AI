import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { Menu, Plus, MessageSquare, Settings, Sparkles, Send, Paperclip, Mic, PanelLeftClose, Trash2, X, Bot, User, ChevronDown, Sun, Moon, Zap } from "lucide-react";
import "./style.css";

const starterPrompts = [
  ["Lightbulb", "Help me understand a difficult topic"],
  ["Code", "Write or debug some code"],
  ["PenLine", "Draft a message or document"],
  ["Compass", "Help me plan something"]
];
const newChat = () => ({ id: crypto.randomUUID(), title: "New chat", messages: [] });

function App() {
  const [chats, setChats] = useState(() => {
    try { return JSON.parse(localStorage.getItem("omni_chats") || "[]"); } catch { return []; }
  });
  const [activeId, setActiveId] = useState(() => localStorage.getItem("omni_active") || null);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [model, setModel] = useState("gpt-4.1-mini");
  const [dark, setDark] = useState(true);
  const [notice, setNotice] = useState("");
  const bottomRef = useRef(null);
  const active = chats.find(c => c.id === activeId) || null;

  useEffect(() => { localStorage.setItem("omni_chats", JSON.stringify(chats)); }, [chats]);
  useEffect(() => { if (activeId) localStorage.setItem("omni_active", activeId); }, [activeId]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [active?.messages, busy]);

  function startChat() {
    const c = newChat();
    setChats(prev => [c, ...prev]);
    setActiveId(c.id);
    setInput("");
    setNotice("");
  }
  function updateMessages(id, messages) {
    setChats(prev => prev.map(c => c.id === id ? { ...c, messages, title: c.title === "New chat" && messages[0]?.role === "user" ? messages[0].content.slice(0, 34) : c.title } : c));
  }
  async function send(text = input) {
    const content = text.trim();
    if (!content || busy) return;
    let chat = active;
    if (!chat) {
      chat = newChat();
      setChats(prev => [chat, ...prev]);
      setActiveId(chat.id);
    }
    const updated = [...chat.messages, { role: "user", content }];
    updateMessages(chat.id, updated);
    setInput("");
    setBusy(true);
    setNotice("");
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: updated, model })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Request failed.");
      updateMessages(chat.id, [...updated, { role: "assistant", content: data.reply }]);
    } catch (e) {
      setNotice(e.message || "Couldn't reach OMNI. Check your connection and server.");
    } finally { setBusy(false); }
  }
  function removeChat(id, e) {
    e?.stopPropagation();
    const remaining = chats.filter(c => c.id !== id);
    setChats(remaining);
    if (activeId === id) setActiveId(remaining[0]?.id || null);
  }
  const hasMessages = Boolean(active?.messages?.length);

  return <div className={dark ? "app dark" : "app light"}>
    {sidebarOpen && <aside className="sidebar">
      <div className="side-top">
        <div className="brand"><div className="brand-mark">O</div><span>OMNI</span></div>
        <button className="icon-btn mobile-close" onClick={() => setSidebarOpen(false)} aria-label="Close sidebar"><X size={18}/></button>
      </div>
      <button className="new-chat" onClick={startChat}><Plus size={18}/> New chat <span>⌘ K</span></button>
      <div className="history-label">YOUR CHATS</div>
      <div className="history">
        {chats.map(c => <button key={c.id} className={`history-item ${c.id === activeId ? "selected" : ""}`} onClick={() => setActiveId(c.id)}>
          <MessageSquare size={16}/><span>{c.title}</span><span className="delete-chat" onClick={e => removeChat(c.id,e)}><Trash2 size={14}/></span>
        </button>)}
        {!chats.length && <p className="empty-history">Your conversations will appear here.</p>}
      </div>
      <div className="side-bottom">
        <button className="profile" onClick={() => setSettingsOpen(true)}><div className="avatar">O</div><div><b>OMNI</b><small>Personal AI workspace</small></div><Settings size={17}/></button>
      </div>
    </aside>}
    <main className="main">
      <header className="topbar">
        <div className="top-left">
          {!sidebarOpen && <button className="icon-btn" onClick={() => setSidebarOpen(true)}><Menu size={19}/></button>}
          <span className="mobile-brand">OMNI</span>
          <button className="model-pill" onClick={() => setSettingsOpen(true)}><span className="status-dot"/>{model}<ChevronDown size={14}/></button>
        </div>
        <div className="top-actions">
          <button className="icon-btn" title="Toggle theme" onClick={() => setDark(!dark)}>{dark ? <Sun size={18}/> : <Moon size={18}/>}</button>
          <button className="icon-btn" title="Settings" onClick={() => setSettingsOpen(true)}><Settings size={18}/></button>
        </div>
      </header>
      <section className={`conversation ${hasMessages ? "with-messages" : ""}`}>
        {!hasMessages ? <div className="welcome">
          <div className="welcome-orb"><Sparkles size={27}/></div>
          <p className="eyebrow">YOUR AI, READY WHEN YOU ARE</p>
          <h1>What’s on your<br/><span>mind today?</span></h1>
          <p className="welcome-sub">Ask anything. Explore ideas. Make something extraordinary.</p>
          <div className="suggestions">
            {starterPrompts.map(([icon,label]) => <button key={label} onClick={() => send(label)}><span>{icon === "Lightbulb" ? "✦" : icon === "Code" ? "</>" : icon === "PenLine" ? "✎" : "↗"}</span>{label}<b>↗</b></button>)}
          </div>
        </div> : <div className="messages">
          {active.messages.map((m,i) => <article className={`message ${m.role}`} key={i}>
            <div className={`message-avatar ${m.role}`}>{m.role === "assistant" ? <Sparkles size={16}/> : <User size={16}/>}</div>
            <div className="message-body"><div className="message-author">{m.role === "assistant" ? "OMNI" : "You"}</div><div className="message-text">{m.content}</div></div>
          </article>)}
          {busy && <article className="message assistant"><div className="message-avatar assistant"><Sparkles size={16}/></div><div className="message-body"><div className="message-author">OMNI</div><div className="typing"><i/><i/><i/></div></div></article>}
          <div ref={bottomRef}/>
        </div>}
      </section>
      <div className="composer-wrap">
        {notice && <div className="notice">{notice}</div>}
        <div className="composer">
          <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if(e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} placeholder="Message OMNI..." rows={1} disabled={busy}/>
          <div className="composer-bottom">
            <div className="composer-tools"><button className="tool-btn" title="Attachments coming soon" onClick={() => setNotice("File and image uploads are not included in this starter build yet.")}><Paperclip size={17}/></button><span className="tool-hint">Shift + Enter for a new line</span></div>
            <div className="send-tools"><button className="tool-btn mic" title="Voice input coming soon" onClick={() => setNotice("Voice input is a planned next feature.")}><Mic size={17}/></button><button className="send-btn" disabled={!input.trim() || busy} onClick={() => send()}><Send size={17}/></button></div>
          </div>
        </div>
        <p className="disclaimer">OMNI can make mistakes. Check important information.</p>
      </div>
    </main>
    {settingsOpen && <div className="modal-backdrop" onClick={() => setSettingsOpen(false)}><div className="settings-modal" onClick={e => e.stopPropagation()}>
      <div className="modal-head"><div><h2>OMNI settings</h2><p>Personalise your AI workspace.</p></div><button className="icon-btn" onClick={() => setSettingsOpen(false)}><X size={19}/></button></div>
      <label>AI model<select value={model} onChange={e => setModel(e.target.value)}><option value="gpt-4.1-mini">GPT-4.1 mini — fast and efficient</option><option value="gpt-4.1">GPT-4.1 — advanced reasoning</option><option value="gpt-4o">GPT-4o — multimodal</option></select></label>
      <div className="settings-note"><Zap size={17}/> Model availability depends on your OpenAI API account and billing.</div>
      <button className="done-btn" onClick={() => setSettingsOpen(false)}>Done</button>
    </div></div>}
  </div>;
}
createRoot(document.getElementById("root")).render(<App/>);